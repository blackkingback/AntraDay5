﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

class Program
{
    static void Main(string[] args)
    {
        // Read input sentence
        Console.WriteLine("Enter a sentence:");
        string input = Console.ReadLine();

        // Use Regex to identify words and separators
        string pattern = @"([A-Za-z0-9\+\#]+|[\.,:;\(\)&\[\]""'\\\/!? ]+)";
        MatchCollection matches = Regex.Matches(input, pattern);

        List<string> words = new List<string>();
        List<string> separators = new List<string>();

        // Separate words and separators
        foreach (Match match in matches)
        {
            if (Regex.IsMatch(match.Value, @"[A-Za-z0-9\+\#]+"))
            {
                words.Add(match.Value);
            }
            else
            {
                separators.Add(match.Value);
            }
        }

        // Reverse the words list
        words.Reverse();

        // Reconstruct the sentence
        StringBuilder result = new StringBuilder();
        int wordIndex = 0;
        int separatorIndex = 0;

        foreach (Match match in matches)
        {
            if (Regex.IsMatch(match.Value, @"[A-Za-z0-9\+\#]+"))
            {
                result.Append(words[wordIndex++]);
            }
            else
            {
                result.Append(separators[separatorIndex++]);
            }
        }

        // Print the reversed sentence
        Console.WriteLine(result.ToString());
    }
}
