﻿using System;
using System.Collections.Generic;

class Program
{
    static void Main(string[] args)
    {
        int startNum = 10;
        int endNum = 50;
        int[] primes = FindPrimesInRange(startNum, endNum);

        Console.WriteLine("Prime numbers in the range:");
        foreach (int prime in primes)
        {
            Console.Write(prime + " ");
        }
    }

    static int[] FindPrimesInRange(int startNum, int endNum)
    {
        List<int> primesList = new List<int>();

        for (int num = startNum; num <= endNum; num++)
        {
            if (IsPrime(num))
            {
                primesList.Add(num);
            }
        }

        return primesList.ToArray();
    }

    static bool IsPrime(int number)
    {
        if (number <= 1) return false;
        if (number == 2) return true;

        for (int i = 2; i <= Math.Sqrt(number); i++)
        {
            if (number % i == 0) return false;
        }

        return true;
    }
}