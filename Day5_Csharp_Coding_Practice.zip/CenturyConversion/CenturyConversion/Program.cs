﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter number of centuries: ");
        int centuries = int.Parse(Console.ReadLine());

        // Constants
        const int yearsInCentury = 100;
        const int daysInYear = 36524 / 100; // Considering leap years over a century
        const int hoursInDay = 24;
        const int minutesInHour = 60;
        const int secondsInMinute = 60;
        const int millisecondsInSecond = 1000;
        const int microsecondsInMillisecond = 1000;
        const int nanosecondsInMicrosecond = 1000;

        // Calculations
        int years = centuries * yearsInCentury;
        int days = years * daysInYear;
        long hours = (long)days * hoursInDay;
        long minutes = hours * minutesInHour;
        long seconds = minutes * secondsInMinute;
        long milliseconds = seconds * millisecondsInSecond;
        long microseconds = milliseconds * microsecondsInMillisecond;
        long nanoseconds = microseconds * nanosecondsInMicrosecond;

        // Output
        Console.WriteLine($"{centuries} centuries = {years} years = {days} days = {hours} hours = {minutes} minutes = {seconds} seconds = {milliseconds} milliseconds = {microseconds} microseconds = {nanoseconds} nanoseconds");
    }
}