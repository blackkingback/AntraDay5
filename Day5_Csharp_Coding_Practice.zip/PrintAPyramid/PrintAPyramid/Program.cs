﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.Write("Enter the number of levels for the pyramid: ");
        int levels = int.Parse(Console.ReadLine());

        for (int i = 1; i <= levels; i++)
        {
            // Print spaces
            for (int j = 1; j <= levels - i; j++)
            {
                Console.Write(" ");
            }

            // Print stars
            for (int k = 1; k <= (2 * i - 1); k++)
            {
                Console.Write("*");
            }

            // Move to the next line
            Console.WriteLine();
        }
    }
}