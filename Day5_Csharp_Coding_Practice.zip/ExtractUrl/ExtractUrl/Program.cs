﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Read input URL
        Console.WriteLine("Enter the URL:");
        string input = Console.ReadLine();

        // Variables to store the parts of the URL
        string protocol = null;
        string server = null;
        string resource = null;

        // Find the protocol
        int protocolEndIndex = input.IndexOf("://");
        if (protocolEndIndex != -1)
        {
            protocol = input.Substring(0, protocolEndIndex);
            input = input.Substring(protocolEndIndex + 3); // Remove the protocol and "://"
        }

        // Find the server and resource
        int resourceStartIndex = input.IndexOf('/');
        if (resourceStartIndex != -1)
        {
            server = input.Substring(0, resourceStartIndex);
            resource = input.Substring(resourceStartIndex + 1);
        }
        else
        {
            server = input;
        }

        // Output the parsed parts
        Console.WriteLine("[protocol] = " + (protocol ?? "(none)"));
        Console.WriteLine("[server] = " + server);
        Console.WriteLine("[resource] = " + (resource ?? "(none)"));
    }
}
