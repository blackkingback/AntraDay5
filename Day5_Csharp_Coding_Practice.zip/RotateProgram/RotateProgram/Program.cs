﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        // Read input array
        Console.WriteLine("Enter the elements of the array (space separated):");
        int[] array = Console.ReadLine().Split().Select(int.Parse).ToArray();

        // Read the number of rotations
        Console.WriteLine("Enter the number of rotations:");
        int k = int.Parse(Console.ReadLine());

        int n = array.Length;
        int[] sumArray = new int[n];

        // Perform k rotations and sum the arrays
        for (int r = 1; r <= k; r++)
        {
            int[] rotatedArray = new int[n];
            for (int i = 0; i < n; i++)
            {
                rotatedArray[(i + r) % n] = array[i];
            }

            // Add the rotated array to the sum array
            for (int i = 0; i < n; i++)
            {
                sumArray[i] += rotatedArray[i];
            }
        }

        // Print the sum array
        Console.WriteLine("Sum array after " + k + " rotations:");
        Console.WriteLine(string.Join(" ", sumArray));
    }
}