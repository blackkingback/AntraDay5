﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Define the birth date
        Console.Write("Enter your birth date (yyyy-MM-dd): ");
        DateTime birthDate = DateTime.Parse(Console.ReadLine());

        // Calculate the number of days old the person is
        DateTime currentDate = DateTime.Now;
        TimeSpan ageTimeSpan = currentDate - birthDate;
        int daysOld = (int)ageTimeSpan.TotalDays;

        Console.WriteLine($"You are {daysOld} days old.");

        // Calculate the date of the next 10,000 day anniversary
        int daysToNextAnniversary = 10000 - (daysOld % 10000);
        DateTime nextAnniversary = currentDate.AddDays(daysToNextAnniversary);

        Console.WriteLine($"Your next 10,000-day anniversary will be on {nextAnniversary:yyyy-MM-dd}.");
    }
}