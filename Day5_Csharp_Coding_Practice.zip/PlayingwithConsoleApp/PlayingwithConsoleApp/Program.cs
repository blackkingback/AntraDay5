﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Please input your name : ");
String PersonName = Console.ReadLine();
Console.WriteLine("Hello, Mr. " + PersonName);
