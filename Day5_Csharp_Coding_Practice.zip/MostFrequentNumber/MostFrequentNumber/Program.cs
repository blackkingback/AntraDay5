﻿using System;
using System.Collections.Generic;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        // Read input array
        Console.WriteLine("Enter the elements of the array (space separated):");
        int[] array = Console.ReadLine().Split().Select(int.Parse).ToArray();

        Dictionary<int, int> frequencyDict = new Dictionary<int, int>();

        // Calculate frequency of each number
        foreach (int num in array)
        {
            if (frequencyDict.ContainsKey(num))
            {
                frequencyDict[num]++;
            }
            else
            {
                frequencyDict[num] = 1;
            }
        }

        // Find the most frequent number
        int maxFrequency = frequencyDict.Values.Max();
        int mostFrequentNumber = array.First(num => frequencyDict[num] == maxFrequency);

        // Output the result
        Console.WriteLine($"The number {mostFrequentNumber} is the most frequent (occurs {maxFrequency} times).");
    }
}
