﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Outer loop counting from 1 to 4
        for (int increment = 1; increment <= 4; increment++)
        {
            // Inner loop counting from 0 to 24 with the outer loop control variable as the increment
            for (int i = 0; i <= 24; i += increment)
            {
                Console.Write(i);
                if (i + increment <= 24) // To avoid trailing comma
                {
                    Console.Write(", ");
                }
            }
            Console.WriteLine();
        }
    }
}