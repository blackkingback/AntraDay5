﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // Read input string
        Console.WriteLine("Enter a string:");
        string input = Console.ReadLine();

        // Method 1: Convert to char array, reverse it, then convert back to string
        char[] charArray = input.ToCharArray();
        Array.Reverse(charArray);
        string reversedString = new string(charArray);
        Console.WriteLine("Reversed string (method 1): " + reversedString);

        // Method 2: Print the letters of the string in reverse order using a for-loop
        Console.Write("Reversed string (method 2): ");
        for (int i = input.Length - 1; i >= 0; i--)
        {
            Console.Write(input[i]);
        }
        Console.WriteLine();
    }
}
