﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

class Program
{
    static void Main(string[] args)
    {
        // Read input text
        Console.WriteLine("Enter the text:");
        string input = Console.ReadLine();

        // Extract words from the text
        string[] words = Regex.Split(input, @"\W+");

        // HashSet to store unique palindromes
        HashSet<string> palindromes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        // Check each word for palindrome
        foreach (string word in words)
        {
            if (IsPalindrome(word) && word.Length > 0)
            {
                palindromes.Add(word);
            }
        }

        // Sort the palindromes
        List<string> sortedPalindromes = palindromes.ToList();
        sortedPalindromes.Sort(StringComparer.OrdinalIgnoreCase);

        // Print the palindromes
        Console.WriteLine(string.Join(", ", sortedPalindromes));
    }

    // Method to check if a word is a palindrome
    static bool IsPalindrome(string word)
    {
        int length = word.Length;
        for (int i = 0; i < length / 2; i++)
        {
            if (char.ToLower(word[i]) != char.ToLower(word[length - 1 - i]))
            {
                return false;
            }
        }
        return true;
    }
}
