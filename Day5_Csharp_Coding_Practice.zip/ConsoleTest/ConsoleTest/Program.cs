﻿using System;

int max = 500;
byte previousValue = 0;

for (byte i = 0; i < max; i++)
{
    Console.WriteLine(i);

    // Check for wrap-around
    if (i < previousValue)
    {
        Console.WriteLine("Warning: Byte overflow detected!");
        break; // Optionally break out of the loop to prevent infinite loop
    }

    previousValue = i;
}

/// When you run the console application, it will enter an infinite loop. This is because the variable i is of type byte, 
/// which is an 8-bit unsigned integer that ranges from 0 to 255. 
/// Once i reaches 255, it wraps around to 0 instead of continuing to 500. 
/// This results in the loop never terminating, continuously printing values from 0 to 255.
