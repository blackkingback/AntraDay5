﻿using System;
using System.Linq;

class Program
{
    static void Main(string[] args)
    {
        // Read input array
        Console.WriteLine("Enter the elements of the array (space separated):");
        int[] array = Console.ReadLine().Split().Select(int.Parse).ToArray();

        int maxLength = 1;
        int currentLength = 1;
        int bestStart = 0;
        int currentStart = 0;

        for (int i = 1; i < array.Length; i++)
        {
            if (array[i] == array[i - 1])
            {
                currentLength++;
            }
            else
            {
                currentLength = 1;
                currentStart = i;
            }

            if (currentLength > maxLength)
            {
                maxLength = currentLength;
                bestStart = currentStart;
            }
        }

        // Print the longest sequence
        Console.WriteLine("Longest sequence of equal elements:");
        for (int i = bestStart; i < bestStart + maxLength; i++)
        {
            Console.Write(array[i] + " ");
        }
        Console.WriteLine();
    }
}
