﻿using System;

class Program
{
    static void Main(string[] args)
    {
        // For testing, you can set a specific time here:
        // DateTime currentTime = new DateTime(2024, 5, 28, 14, 0, 0); // Example: 2:00 PM
        // Use the following line for the actual current time:
        DateTime currentTime = DateTime.Now;

        int hour = currentTime.Hour;

        if (hour >= 5 && hour < 12)
        {
            Console.WriteLine("Good Morning");
        }

        if (hour >= 12 && hour < 17)
        {
            Console.WriteLine("Good Afternoon");
        }

        if (hour >= 17 && hour < 21)
        {
            Console.WriteLine("Good Evening");
        }

        if ((hour >= 21 && hour <= 23) || (hour >= 0 && hour < 5))
        {
            Console.WriteLine("Good Night");
        }
    }
}