﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Type: sbyte");
        Console.WriteLine($"Size: {sizeof(sbyte)} bytes");
        Console.WriteLine($"Min Value: {sbyte.MinValue}");
        Console.WriteLine($"Max Value: {sbyte.MaxValue}");
        Console.WriteLine();

        Console.WriteLine("Type: byte");
        Console.WriteLine($"Size: {sizeof(byte)} bytes");
        Console.WriteLine($"Min Value: {byte.MinValue}");
        Console.WriteLine($"Max Value: {byte.MaxValue}");
        Console.WriteLine();

        Console.WriteLine("Type: short");
        Console.WriteLine($"Size: {sizeof(short)} bytes");
        Console.WriteLine($"Min Value: {short.MinValue}");
        Console.WriteLine($"Max Value: {short.MaxValue}");
        Console.WriteLine();

        Console.WriteLine("Type: ushort");
        Console.WriteLine($"Size: {sizeof(ushort)} bytes");
        Console.WriteLine($"Min Value: {ushort.MinValue}");
        Console.WriteLine($"Max Value: {ushort.MaxValue}");
        Console.WriteLine();

        Console.WriteLine("Type: int");
        Console.WriteLine($"Size: {sizeof(int)} bytes");
        Console.WriteLine($"Min Value: {int.MinValue}");
        Console.WriteLine($"Max Value: {int.MaxValue}");
        Console.WriteLine();

        Console.WriteLine("Type: uint");
        Console.WriteLine($"Size: {sizeof(uint)} bytes");
        Console.WriteLine($"Min Value: {uint.MinValue}");
        Console.WriteLine($"Max Value: {uint.MaxValue}");
        Console.WriteLine();

        Console.WriteLine("Type: long");
        Console.WriteLine($"Size: {sizeof(long)} bytes");
        Console.WriteLine($"Min Value: {long.MinValue}");
        Console.WriteLine($"Max Value: {long.MaxValue}");
        Console.WriteLine();

        Console.WriteLine("Type: ulong");
        Console.WriteLine($"Size: {sizeof(ulong)} bytes");
        Console.WriteLine($"Min Value: {ulong.MinValue}");
        Console.WriteLine($"Max Value: {ulong.MaxValue}");
        Console.WriteLine();

        Console.WriteLine("Type: float");
        Console.WriteLine($"Size: {sizeof(float)} bytes");
        Console.WriteLine($"Min Value: {float.MinValue}");
        Console.WriteLine($"Max Value: {float.MaxValue}");
        Console.WriteLine();

        Console.WriteLine("Type: double");
        Console.WriteLine($"Size: {sizeof(double)} bytes");
        Console.WriteLine($"Min Value: {double.MinValue}");
        Console.WriteLine($"Max Value: {double.MaxValue}");
        Console.WriteLine();

        Console.WriteLine("Type: decimal");
        Console.WriteLine($"Size: {sizeof(decimal)} bytes");
        Console.WriteLine($"Min Value: {decimal.MinValue}");
        Console.WriteLine($"Max Value: {decimal.MaxValue}");
        Console.WriteLine();
    }
}