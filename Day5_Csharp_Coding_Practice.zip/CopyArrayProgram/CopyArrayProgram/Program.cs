﻿class Program
{
    static void Main(string[] args)
    {
        // Create and initialize the first array with 10 items
        int[] originalArray = new int[10];
        for (int i = 0; i < originalArray.Length; i++)
        {
            originalArray[i] = i * 2; // Example values: 0, 2, 4, 6, 8, 10, 12, 14, 16, 18
        }

        // Create a second array with the same length as the original array
        int[] copiedArray = new int[originalArray.Length];

        // Copy values from the original array to the new array
        for (int i = 0; i < originalArray.Length; i++)
        {
            copiedArray[i] = originalArray[i];
        }

        // Print the contents of the original array
        Console.WriteLine("Original Array:");
        for (int i = 0; i < originalArray.Length; i++)
        {
            Console.Write(originalArray[i] + " ");
        }
        Console.WriteLine();

        // Print the contents of the copied array
        Console.WriteLine("Copied Array:");
        for (int i = 0; i < copiedArray.Length; i++)
        {
            Console.Write(copiedArray[i] + " ");
        }
        Console.WriteLine();
    }
}